from django.apps import AppConfig


class ComparisonConfig(AppConfig):
    name = 'comparison'
